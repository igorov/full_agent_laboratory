# Bases de datos

## Información General

| Campo | Valor |
|---|---|
| **Motor** | PostgreSQL 14+ |
| **Esquema** | `prometheus` |
| **ORM** | GORM v1.31 |
| **Driver** | `jackc/pgx/v5` |
| **Modo SSL** | Configurable via `DB_SSL_MODE` (`disable` por defecto) |

## Diagrama de Base de Datos

```mermaid
erDiagram
    agents {
        uuid id PK
        varchar(100) agent_name
        text context_prompt
        text agent_prompt
        boolean active
        text inactive_message
        text topic_tools
        text detail_text
        varchar(50) source_access
        text source_blacklist
        uuid empresa_id
        timestamp created_at
        timestamp updated_at
    }

    documents {
        int id PK
        varchar(100) name
        varchar(100) resource
        int document_type_id
        uuid agent_id FK
        text content
        text points
        timestamp created_at
        timestamp updated_at
    }

    agents ||--o{ documents : "tiene"
```

## Descripción de Tablas

| Tabla | Descripción | Propósito Principal |
|---|---|---|
| `prometheus.agents` | Almacena los agentes de IA configurados por empresa. Incluye nombre, prompt de contexto, estado activo/inactivo y referencia a la empresa propietaria. | Gestionar la identidad, configuración de prompt y ciclo de vida (activo/inactivo) de cada agente de IA dentro de una empresa. |
| `prometheus.documents` | Almacena los documentos de conocimiento vinculados a un agente. Incluye nombre, recurso de origen, contenido textual y puntos clave extraídos. | Proveer la base de conocimiento (RAG) a cada agente; cada documento contiene el contenido textual indexable y la referencia al recurso original. |

## Relaciones Principales

- **`prometheus.agents` → `prometheus.documents`**: relación **uno a muchos**. Un agente puede tener múltiples documentos de conocimiento asociados. La clave foránea `documents.agent_id` referencia `agents.id`.
