# Variables de entorno

| Variable | Descripción | Valores |
|---|---|---|
| `PORT` | Puerto en el que escucha el servidor HTTP. Cloud Run inyecta este valor automáticamente. | `8080`, `3000` |
| `APP_ENV` | Entorno de ejecución. En `local` se activa el middleware de mock para simular el header de GCP API Gateway. | `local`, `development`, `production` |
| `LOG_LEVEL` | Nivel de log del logger estructurado (zap). | `debug`, `info`, `warn`, `error` |
| `DB_HOST` | Hostname o IP del servidor PostgreSQL. | `localhost`, `10.0.0.5`, `db.internal` |
| `DB_PORT` | Puerto del servidor PostgreSQL. | `5432` |
| `DB_NAME` | Nombre de la base de datos PostgreSQL. | `prometheus` |
| `DB_USER` | Usuario de conexión a PostgreSQL. | `postgres`, `app_user` |
| `DB_PASSWORD` | Contraseña del usuario de PostgreSQL. | `your_password_here` |
| `DB_SSL_MODE` | Modo SSL para la conexión a PostgreSQL. | `disable`, `require`, `verify-full` |
| `CORS_ALLOW_ORIGINS` | Orígenes HTTP permitidos por la política CORS, separados por coma. Incompatible con `*` cuando `CORS_ALLOW_CREDENTIALS=true`. | `*`, `https://app.example.com` |
| `CORS_ALLOW_CREDENTIALS` | Indica si el navegador debe incluir cookies/credenciales en las peticiones CORS. | `true`, `false` |
