# prometheus-agent-management-api

## Descripción y propósito

API REST para la gestión de agentes de inteligencia artificial dentro de la plataforma Prometheus. Permite crear, consultar, actualizar y deshabilitar agentes de IA, así como consultar los documentos de conocimiento asociados a cada agente. El acceso está segmentado por empresa (`id_empresa`), extraído automáticamente del token JWT propagado por GCP API Gateway a través del header `x-apigateway-api-userinfo`.

## Repositorio

https://github.com/runatech-ai/prometheus-agent-management-api

## Requisitos

- **Go 1.23+** — Lenguaje de programación principal
- **Docker** — Para construir y ejecutar la imagen del servicio
- **PostgreSQL 14+** — Base de datos relacional (esquema `prometheus`)
- **GCP API Gateway** — Propaga el header `x-apigateway-api-userinfo` con la información del usuario autenticado (solo requerido en ambientes desplegados; en local se simula con `APP_ENV=local`)

## Estructura del proyecto

```
prometheus-agent-management-api/
├── api/                                    # Capa HTTP: controladores y rutas
│   ├── controllers/                        # Handlers de las peticiones HTTP
│   │   ├── agent-controller.go             # Controlador de agentes
│   │   ├── container.go                    # Contenedor de controladores
│   │   └── document-controller.go          # Controlador de documentos
│   └── routes/                             # Registro de rutas Fiber
│       └── agent-management-routes.go      # Definición de rutas del dominio agentes
├── cmd/                                    # Punto de entrada y configuración de la aplicación
│   ├── server/                             # Inicialización del servidor HTTP
│   │   ├── dev/                            # Datos mock para desarrollo local
│   │   ├── middleware.go                   # Middlewares (contexto, CORS, interceptor de respuestas)
│   │   └── server.go                       # Arranque del servidor y health checks
│   ├── utils/                              # Utilidades transversales
│   │   ├── database/                       # Configuración y conexión a PostgreSQL
│   │   ├── environment/                    # Carga de variables de entorno
│   │   └── log/                            # Logger estructurado (zap)
│   ├── container.go                        # Composition root: cableado de dependencias
│   └── main.go                             # Función principal
├── pkg/                                    # Lógica de negocio y dominio
│   ├── appctx/                             # Claves y helpers del contexto de aplicación
│   │   └── context.go                      # Definición de claves y getters del contexto
│   ├── entities/                           # DTOs y modelos de API
│   │   └── agent-api-entity.go             # Entidades, requests y responses del dominio
│   ├── repositories/                       # Contratos e implementaciones de acceso a datos
│   │   ├── impl/                           # Implementaciones concretas con GORM
│   │   │   ├── agent-repository-impl.go    # Implementación del repositorio de agentes
│   │   │   ├── document-repository-impl.go # Implementación del repositorio de documentos
│   │   │   └── db_errors.go                # Traducción de errores de base de datos
│   │   ├── models/                         # Modelos GORM (tablas de BD)
│   │   │   ├── agent-model.go              # Modelo de la tabla prometheus.agents
│   │   │   └── document-model.go           # Modelo de la tabla prometheus.documents
│   │   ├── agent-repository.go             # Interfaz del repositorio de agentes
│   │   └── document-repository.go          # Interfaz del repositorio de documentos
│   └── services/                           # Capa de lógica de negocio
│       ├── agent-service.go                # Servicio de agentes
│       └── document-service.go             # Servicio de documentos
├── tests/                                  # Tests unitarios e integración
├── Dockerfile                              # Imagen Docker para despliegue en Cloud Run
├── go.mod                                  # Dependencias del módulo Go
├── go.sum                                  # Checksums de dependencias
└── README.md                               # Documentación principal del proyecto
```

## Quickstart

```bash
# 1. Clonar el repositorio
git clone https://github.com/runatech-ai/prometheus-agent-management-api.git
cd prometheus-agent-management-api

# 2. Copiar y completar las variables de entorno
cp .env.example .env
# Editar .env con los valores reales

# 3. Ejecutar en modo local (sin compilar ni Docker)
APP_ENV=local go run ./cmd/...
```

## Compilación del binario

El binario se compila de forma estática (`CGO_ENABLED=0`) apuntando a Linux/amd64, que es el target del contenedor Docker y de Cloud Run.

### Mac / Linux

```bash
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o main ./cmd/
```

### Windows (PowerShell)

```powershell
$env:CGO_ENABLED="0"; $env:GOOS="linux"; $env:GOARCH="amd64"; go build -o main ./cmd/
```

### Windows (CMD)

```cmd
set CGO_ENABLED=0
set GOOS=linux
set GOARCH=amd64
go build -o main ./cmd/
```

## Generación de la imagen Docker

Una vez compilado el binario (`main`), construir y ejecutar la imagen:

```bash
# Construir la imagen
docker build -t prometheus-agent-management-api .

# Ejecutar localmente
docker run --env-file .env -p 8080:8080 prometheus-agent-management-api
```

> **Nota:** el `Dockerfile` usa `alpine:3.17` con `ca-certificates` y `tzdata`. No incluye el toolchain de Go, por lo que el binario debe compilarse antes de ejecutar `docker build`.

## Configuración esencial

| Variable | Descripción | Valor por defecto |
|---|---|---|
| `PORT` | Puerto HTTP del servidor | `8080` |
| `APP_ENV` | Entorno de ejecución (`local`, `development`, `production`) | `production` |
| `LOG_LEVEL` | Nivel de logging (`debug`, `info`, `warn`, `error`) | `info` |
| `DB_HOST` | Host de PostgreSQL | — |
| `DB_PORT` | Puerto de PostgreSQL | `5432` |
| `DB_NAME` | Nombre de la base de datos | — |
| `DB_USER` | Usuario de PostgreSQL | — |
| `DB_PASSWORD` | Contraseña de PostgreSQL | — |
| `DB_SSL_MODE` | Modo SSL de PostgreSQL | `disable` |
| `CORS_ALLOW_ORIGINS` | Orígenes permitidos para CORS | `*` |
| `CORS_ALLOW_CREDENTIALS` | Habilitar credenciales en CORS | `false` |

Ver detalle completo en [docs/configurations.md](docs/configurations.md).

## Despliegue

Dónde vive: GCP Cloud Run

Ambientes: Dev / Stg / Prod → docs/deployment.md