package entities

// AgentEntity representa los datos de un agente tal como se exponen en la API.
type AgentEntity struct {
	// Campos de la entidad del API
	ID          string `json:"id"`
	AgentName   string `json:"agent_name"`
	AgentPrompt string `json:"agent_prompt"`
	IDEmpresa   string `json:"id_empresa"`
	CreatedAt   string `json:"created_at"`
	UpdatedAt   string `json:"updated_at"`
}

// DocumentEntity representa los datos de un documento asociado a un agente.
type DocumentEntity struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	URL  string `json:"url"`
}

// UserInfo representa la información del usuario autenticado, extraída del token del API Gateway.
type UserInfo struct {
	IDUsuario     string   `json:"id_usuario"`
	Username      string   `json:"username"`
	Nombre        string   `json:"nombre"`
	Email         string   `json:"email"`
	IDEmpresa     string   `json:"id_empresa"`
	CodigoEmpresa string   `json:"codigo_empresa"`
	NombreEmpresa string   `json:"nombre_empresa"`
	Perfiles      []string `json:"perfiles"`
	PerfilActivo  string   `json:"perfil_activo"`
	NombreEquipo  string   `json:"nombre_equipo"`
}

// AgentCreateRequest es el cuerpo de la petición para crear o actualizar un agente.
type AgentCreateRequest struct {
	AgentName   string `json:"agent_name"`
	AgentPrompt string `json:"agent_prompt"`
	IDEmpresa   string `json:"id_empresa"`
}

// DocumentRequest es el cuerpo de la petición para crear o actualizar un documento.
type DocumentRequest struct {
	Name           string  `json:"name"`
	DocumentTypeID int     `json:"document_type_id"`
	Resource       *string `json:"resource"`
}

// BaseResponse es la estructura genérica de respuesta envuelta en la API.
// El campo Status indica el resultado ("success" o "error") y Data contiene el payload.
type BaseResponse[T any] struct {
	Status string `json:"status"`
	Data   T      `json:"data"`
}

// AgentListResponse es el tipo de respuesta para colecciones de agentes.
type AgentListResponse = BaseResponse[[]AgentEntity]

// AgentResponse es el tipo de respuesta para un agente individual.
type AgentResponse = BaseResponse[AgentEntity]
