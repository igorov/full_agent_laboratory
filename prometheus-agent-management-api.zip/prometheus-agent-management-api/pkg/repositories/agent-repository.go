package repositories

import (
	"context"

	"prometheus-agent-management-api/pkg/entities"
)

// AgentRepository define el contrato de acceso a datos para la entidad Agent.
type AgentRepository interface {
	// GetByCompany retorna todos los agentes pertenecientes a la empresa indicada.
	GetByCompany(ctx context.Context, companyID string) []entities.AgentEntity
	// GetByID retorna el agente con el ID especificado, o nil si no existe.
	GetByID(ctx context.Context, id string) *entities.AgentEntity
	// Create persiste un nuevo agente y retorna la entidad creada.
	Create(ctx context.Context, agent *entities.AgentCreateRequest) (*entities.AgentEntity, error)
	// Update modifica los datos del agente con el ID especificado y retorna la entidad actualizada.
	Update(ctx context.Context, id string, agent *entities.AgentCreateRequest) (*entities.AgentEntity, error)
	// Delete elimina permanentemente el agente con el ID especificado.
	Delete(ctx context.Context, id string) error
	// Disable marca el agente con el ID especificado como inactivo sin eliminarlo.
	Disable(ctx context.Context, id string) error
}
