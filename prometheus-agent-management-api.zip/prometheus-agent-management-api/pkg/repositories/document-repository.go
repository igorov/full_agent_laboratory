package repositories

import (
	"context"

	"prometheus-agent-management-api/pkg/entities"
)

// DocumentRepository define el contrato de acceso a datos para la entidad Document.
type DocumentRepository interface {
	// GetByAgent retorna los documentos asociados al agente indicado, con filtros opcionales por nombre y empresa.
	GetByAgent(ctx context.Context, agentID string, name string, companyId string) []entities.DocumentEntity
	// GetByID retorna el documento con el ID especificado, o nil si no existe.
	GetByID(ctx context.Context, id string) *entities.DocumentEntity
	// Create persiste un nuevo documento y retorna la entidad creada.
	Create(ctx context.Context, document *entities.DocumentRequest) (*entities.DocumentEntity, error)
	// Update actualiza los datos del documento recibido.
	Update(ctx context.Context, document *entities.DocumentEntity) error
	// Delete elimina permanentemente el documento con el ID especificado.
	Delete(ctx context.Context, id string) error
}
