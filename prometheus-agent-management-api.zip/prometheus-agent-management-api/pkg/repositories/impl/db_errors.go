package impl

import (
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5/pgconn"
)

const (
	// pgErrForeignKeyViolation es el código de error de Postgres para violación de llave foránea.
	pgErrForeignKeyViolation = "23503"
	// pgErrUniqueViolation es el código de error de Postgres para violación de restricción única.
	pgErrUniqueViolation = "23505"
)

// translateDBError convierte errores nativos de Postgres en mensajes de negocio legibles.
// Si el error no es un PgError conocido, lo retorna sin modificar.
func translateDBError(err error) error {
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) {
		switch pgErr.Code {
		case pgErrForeignKeyViolation:
			return fmt.Errorf("uno de los valores referenciados no existe")
		case pgErrUniqueViolation:
			return fmt.Errorf("ya existe un registro con esos datos")
		}
	}
	return err
}
