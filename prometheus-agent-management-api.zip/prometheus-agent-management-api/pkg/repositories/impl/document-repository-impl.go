package impl

import (
	"context"
	"strconv"

	"prometheus-agent-management-api/pkg/entities"
	"prometheus-agent-management-api/pkg/repositories"
	"prometheus-agent-management-api/pkg/repositories/models"

	"gorm.io/gorm"
)

// documentRepository es la implementación concreta de DocumentRepository usando GORM.
type documentRepository struct {
	db *gorm.DB
}

// NewDocumentRepository crea una nueva instancia del repository
func NewDocumentRepository(db *gorm.DB) repositories.DocumentRepository {
	return &documentRepository{db: db}
}

// GetByAgent obtiene los documentos de un agente, con filtros opcionales por nombre y empresa
func (r *documentRepository) GetByAgent(ctx context.Context, agentID string, name string, companyId string) []entities.DocumentEntity {
	var docs []models.Document
	query := r.db.WithContext(ctx).Where("prometheus.documents.agent_id = ?", agentID)
	if name != "" {
		query = query.Where("prometheus.documents.name LIKE ?", "%"+name+"%")
	}
	if companyId != "" {
		query = query.
			Joins("JOIN prometheus.agents ON prometheus.agents.id = prometheus.documents.agent_id").
			Where("prometheus.agents.empresa_id = ?", companyId)
	}
	query.Find(&docs)
	result := make([]entities.DocumentEntity, 0, len(docs))
	for _, d := range docs {
		result = append(result, toDocumentEntity(d))
	}
	return result
}

// GetByID obtiene un documento por su ID
func (r *documentRepository) GetByID(ctx context.Context, id string) *entities.DocumentEntity {
	var doc models.Document
	if err := r.db.WithContext(ctx).Where("id = ?", id).First(&doc).Error; err != nil {
		return nil
	}
	entity := toDocumentEntity(doc)
	return &entity
}

// Create crea un nuevo documento
func (r *documentRepository) Create(ctx context.Context, req *entities.DocumentRequest) (*entities.DocumentEntity, error) {
	doc := models.Document{
		Name:           req.Name,
		DocumentTypeID: req.DocumentTypeID,
		Resource:       req.Resource,
	}
	if err := r.db.WithContext(ctx).Create(&doc).Error; err != nil {
		return nil, err
	}
	entity := toDocumentEntity(doc)
	return &entity, nil
}

// Update actualiza un documento existente
func (r *documentRepository) Update(ctx context.Context, req *entities.DocumentEntity) error {
	id, err := strconv.Atoi(req.ID)
	if err != nil {
		return err
	}
	url := req.URL
	doc := models.Document{
		ID:       id,
		Name:     req.Name,
		Resource: &url,
	}
	return r.db.WithContext(ctx).Save(&doc).Error
}

// Delete elimina un documento por su ID
func (r *documentRepository) Delete(ctx context.Context, id string) error {
	return r.db.WithContext(ctx).Delete(&models.Document{}, "id = ?", id).Error
}

// toDocumentEntity convierte un modelo GORM Document a la entidad de dominio DocumentEntity.
func toDocumentEntity(d models.Document) entities.DocumentEntity {
	url := ""
	if d.Resource != nil {
		url = *d.Resource
	}
	return entities.DocumentEntity{
		ID:   strconv.Itoa(d.ID),
		Name: d.Name,
		URL:  url,
	}
}
