package impl

import (
	"context"
	"time"

	logger "prometheus-agent-management-api/cmd/utils/log"
	"prometheus-agent-management-api/pkg/entities"
	"prometheus-agent-management-api/pkg/repositories"
	"prometheus-agent-management-api/pkg/repositories/models"

	"github.com/google/uuid"
	"gorm.io/gorm"
)

// agentRepository es la implementación concreta de AgentRepository usando GORM.
type agentRepository struct {
	db *gorm.DB
}

// NewAgentRepository crea una nueva instancia del repository
func NewAgentRepository(db *gorm.DB) repositories.AgentRepository {
	return &agentRepository{db: db}
}

// GetByCompany obtiene todos los agentes de una empresa
func (r *agentRepository) GetByCompany(ctx context.Context, companyID string) []entities.AgentEntity {
	var agents []models.Agent
	r.db.WithContext(ctx).Where("empresa_id = ?", companyID).Find(&agents)
	result := make([]entities.AgentEntity, 0, len(agents))
	for _, a := range agents {
		result = append(result, toAgentEntity(a))
	}
	return result
}

// GetByID obtiene un agente por su ID
func (r *agentRepository) GetByID(ctx context.Context, id string) *entities.AgentEntity {
	var agent models.Agent
	if err := r.db.WithContext(ctx).Where("id = ?", id).First(&agent).Error; err != nil {
		return nil
	}
	entity := toAgentEntity(agent)
	return &entity
}

// Create crea un nuevo agente
func (r *agentRepository) Create(ctx context.Context, req *entities.AgentCreateRequest) (*entities.AgentEntity, error) {
	agentPrompt := req.AgentPrompt
	agent := models.Agent{
		AgentName:   req.AgentName,
		AgentPrompt: &agentPrompt,
	}
	if req.IDEmpresa != "" {
		empresaID, err := uuid.Parse(req.IDEmpresa)
		if err != nil {
			return nil, err
		}
		agent.EmpresaID = &empresaID
	}
	if err := r.db.WithContext(ctx).Create(&agent).Error; err != nil {
		logger.Error(ctx, "error al crear agente en BD", err)
		return nil, translateDBError(err)
	}
	entity := toAgentEntity(agent)
	return &entity, nil
}

// Update actualiza un agente existente
func (r *agentRepository) Update(ctx context.Context, id string, req *entities.AgentCreateRequest) (*entities.AgentEntity, error) {
	agentID, err := uuid.Parse(id)
	if err != nil {
		return nil, err
	}

	updates := map[string]interface{}{
		"agent_name":   req.AgentName,
		"agent_prompt": req.AgentPrompt,
	}
	if req.IDEmpresa != "" {
		empresaID, err := uuid.Parse(req.IDEmpresa)
		if err != nil {
			return nil, err
		}
		updates["empresa_id"] = empresaID
	}

	if err := r.db.WithContext(ctx).Model(&models.Agent{}).Where("id = ?", agentID).Updates(updates).Error; err != nil {
		logger.Error(ctx, "error al actualizar agente en BD", err)
		return nil, translateDBError(err)
	}

	var updated models.Agent
	if err := r.db.WithContext(ctx).Where("id = ?", agentID).First(&updated).Error; err != nil {
		return nil, err
	}
	entity := toAgentEntity(updated)
	return &entity, nil
}

// Delete elimina un agente por su ID
func (r *agentRepository) Delete(ctx context.Context, id string) error {
	return r.db.WithContext(ctx).Delete(&models.Agent{}, "id = ?", id).Error
}

// Disable deshabilita un agente por su ID
func (r *agentRepository) Disable(ctx context.Context, id string) error {
	return r.db.WithContext(ctx).Model(&models.Agent{}).Where("id = ?", id).Update("active", false).Error
}

// toAgentEntity convierte un modelo GORM Agent a la entidad de dominio AgentEntity.
func toAgentEntity(a models.Agent) entities.AgentEntity {
	agentPrompt := ""
	if a.AgentPrompt != nil {
		agentPrompt = *a.AgentPrompt
	}
	createdAt := ""
	if a.CreatedAt != nil {
		createdAt = a.CreatedAt.Format(time.RFC3339)
	}
	updatedAt := ""
	if a.UpdatedAt != nil {
		updatedAt = a.UpdatedAt.Format(time.RFC3339)
	}
	empresaID := ""
	if a.EmpresaID != nil {
		empresaID = a.EmpresaID.String()
	}
	return entities.AgentEntity{
		ID:          a.ID.String(),
		AgentName:   a.AgentName,
		AgentPrompt: agentPrompt,
		IDEmpresa:   empresaID,
		CreatedAt:   createdAt,
		UpdatedAt:   updatedAt,
	}
}
