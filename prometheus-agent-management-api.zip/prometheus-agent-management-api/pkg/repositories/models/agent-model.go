package models

import (
	"time"

	"github.com/google/uuid"
)

// Agent es el modelo GORM que mapea la tabla prometheus.agents.
type Agent struct {
	ID              uuid.UUID  `gorm:"type:uuid;primaryKey;default:gen_random_uuid()"`
	AgentName       string     `gorm:"column:agent_name;type:varchar(100);uniqueIndex;not null"`
	CreatedAt       *time.Time `gorm:"column:created_at;autoCreateTime"`
	UpdatedAt       *time.Time `gorm:"column:updated_at;autoUpdateTime"`
	ContextPrompt   *string    `gorm:"column:context_prompt;type:text"`
	AgentPrompt     *string    `gorm:"column:agent_prompt;type:text"`
	Active          *bool      `gorm:"column:active;default:true"`
	InactiveMessage *string    `gorm:"column:inactive_message;type:text"`
	TopicTools      *string    `gorm:"column:topic_tools;type:text"`
	DetailText      *string    `gorm:"column:detail_text;type:text"`
	SourceAccess    *string    `gorm:"column:source_access;type:varchar(50)"`
	SourceBlacklist *string    `gorm:"column:source_blacklist;type:text"`
	EmpresaID       *uuid.UUID `gorm:"column:empresa_id;type:uuid"`

	Documents []Document `gorm:"foreignKey:AgentID"`
}

// TableName especifica el nombre de tabla calificado con esquema que usa GORM para este modelo.
func (Agent) TableName() string {
	return "prometheus.agents"
}
