package models

import (
	"time"

	"github.com/google/uuid"
)

// Document es el modelo GORM que mapea la tabla prometheus.documents.
type Document struct {
	ID             int       `gorm:"primaryKey;autoIncrement"`
	Name           string    `gorm:"column:name;type:varchar(100);not null"`
	Resource       *string   `gorm:"column:resource;type:varchar(100)"`
	DocumentTypeID int       `gorm:"column:document_type_id;type:int"`
	AgentID        uuid.UUID `gorm:"column:agent_id;type:uuid;not null"`
	CreatedAt      time.Time `gorm:"column:created_at;autoCreateTime;not null"`
	UpdatedAt      time.Time `gorm:"column:updated_at;autoUpdateTime;not null"`
	Content        string    `gorm:"column:content;type:text;not null"`
	Points         *string   `gorm:"column:points;type:text"`

	Agent Agent `gorm:"foreignKey:AgentID"`
}

// TableName especifica el nombre de tabla calificado con esquema que usa GORM para este modelo.
func (Document) TableName() string {
	return "prometheus.documents"
}
