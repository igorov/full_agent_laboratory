package appctx

import "context"

// contextKey es el tipo privado para las claves del contexto, evita colisiones con otros paquetes.
type contextKey string

const (
	// KeyTransactionID es la clave de contexto para el ID de transacción distribuida.
	KeyTransactionID contextKey = "TransactionId"
	// KeyApplicationID es la clave de contexto para el ID de la aplicación origen.
	KeyApplicationID contextKey = "ApplicationId"
	// KeyProcessID es la clave de contexto para el ID del proceso actual.
	KeyProcessID contextKey = "ProcessId"
	// KeyArtifactChain es la clave de contexto para la cadena de artefactos del flujo.
	KeyArtifactChain contextKey = "ArtifactChain"
	// KeyUserEmail es la clave de contexto para el email del usuario autenticado.
	KeyUserEmail contextKey = "UserEmail"
	// KeyCompanyID es la clave de contexto para el ID de empresa del usuario autenticado.
	KeyCompanyID contextKey = "CompanyId"
)

// GetTransactionID retorna el ID de transacción almacenado en el contexto.
func GetTransactionID(ctx context.Context) string {
	v, _ := ctx.Value(KeyTransactionID).(string)
	return v
}

// GetApplicationID retorna el ID de aplicación almacenado en el contexto.
func GetApplicationID(ctx context.Context) string {
	v, _ := ctx.Value(KeyApplicationID).(string)
	return v
}

// GetProcessID retorna el ID de proceso almacenado en el contexto.
func GetProcessID(ctx context.Context) string {
	v, _ := ctx.Value(KeyProcessID).(string)
	return v
}

// GetArtifactChain retorna la cadena de artefactos almacenada en el contexto.
func GetArtifactChain(ctx context.Context) string {
	v, _ := ctx.Value(KeyArtifactChain).(string)
	return v
}

// GetUserEmail retorna el email del usuario autenticado almacenado en el contexto.
func GetUserEmail(ctx context.Context) string {
	v, _ := ctx.Value(KeyUserEmail).(string)
	return v
}

// GetCompanyID retorna el ID de empresa del usuario autenticado almacenado en el contexto.
func GetCompanyID(ctx context.Context) string {
	v, _ := ctx.Value(KeyCompanyID).(string)
	return v
}
