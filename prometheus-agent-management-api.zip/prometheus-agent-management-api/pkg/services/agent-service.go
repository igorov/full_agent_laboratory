package services

import (
	"context"
	"encoding/json"
	"fmt"

	logger "prometheus-agent-management-api/cmd/utils/log"
	"prometheus-agent-management-api/pkg/entities"
	"prometheus-agent-management-api/pkg/repositories"
)

// AgentService implementa la lógica de negocio para la gestión de agentes.
type AgentService struct {
	repo repositories.AgentRepository
}

// NewAgentService crea y retorna una nueva instancia de AgentService con el repositorio indicado.
func NewAgentService(repo repositories.AgentRepository) *AgentService {
	return &AgentService{repo: repo}
}

// GetByCompany retorna todos los agentes de la empresa especificada.
func (s *AgentService) GetByCompany(ctx context.Context, companyID string) []entities.AgentEntity {
	logger.Debug(ctx, fmt.Sprintf("Inicio del metodo GetByCompany, companyID: %s", companyID))
	return s.repo.GetByCompany(ctx, companyID)
}

// GetByID retorna el agente con el ID especificado, o nil si no existe.
func (s *AgentService) GetByID(ctx context.Context, id string) *entities.AgentEntity {
	logger.Debug(ctx, "Inicio del metodo GetByID")
	return s.repo.GetByID(ctx, id)
}

// Create valida y persiste un nuevo agente, retornando la entidad creada.
func (s *AgentService) Create(ctx context.Context, agent *entities.AgentCreateRequest) (*entities.AgentEntity, error) {
	logger.Debug(ctx, "Inicio del metodo Create")
	if data, err := json.Marshal(agent); err == nil {
		logger.Debug(ctx, fmt.Sprintf("agent: %s", string(data)))
	}
	return s.repo.Create(ctx, agent)
}

// Update actualiza un agente existente
func (s *AgentService) Update(ctx context.Context, id string, agent *entities.AgentCreateRequest) (*entities.AgentEntity, error) {
	logger.Debug(ctx, "Inicio del metodo Update")
	return s.repo.Update(ctx, id, agent)
}

// Delete elimina permanentemente el agente con el ID especificado.
func (s *AgentService) Delete(ctx context.Context, id string) error {
	logger.Debug(ctx, "Inicio del metodo Delete")
	return s.repo.Delete(ctx, id)
}

// Disable marca como inactivo el agente con el ID especificado sin eliminarlo.
func (s *AgentService) Disable(ctx context.Context, id string) error {
	logger.Debug(ctx, "Inicio del metodo Disable")
	return s.repo.Disable(ctx, id)
}

// GetUserInfo retorna la información del usuario autenticado extraída del contexto de la petición.
func (s *AgentService) GetUserInfo(ctx context.Context) entities.UserInfo {
	logger.Debug(ctx, "Inicio del metodo GetUserInfo")
	return entities.UserInfo{
		IDUsuario:     "123",
		Username:      "user",
		Nombre:        "User",
		Email:         "user@example.com",
		IDEmpresa:     "456",
		CodigoEmpresa: "CODE",
		NombreEmpresa: "Company",
		Perfiles:      []string{"PO"},
		PerfilActivo:  "PO",
		NombreEquipo:  "Team",
	}
}
