package services

import (
	"context"

	logger "prometheus-agent-management-api/cmd/utils/log"
	"prometheus-agent-management-api/pkg/entities"
	"prometheus-agent-management-api/pkg/repositories"
)

// DocumentService implementa la lógica de negocio para la gestión de documentos.
type DocumentService struct {
	repo repositories.DocumentRepository
}

// NewDocumentService crea y retorna una nueva instancia de DocumentService con el repositorio indicado.
func NewDocumentService(repo repositories.DocumentRepository) *DocumentService {
	return &DocumentService{repo: repo}
}

// GetByAgent obtiene los documentos de un agente
func (s *DocumentService) GetByAgent(ctx context.Context, agentID string, name string, companyId string) []entities.DocumentEntity {
	logger.Debug(ctx, "Inicio del metodo GetByAgent")
	return s.repo.GetByAgent(ctx, agentID, name, companyId)
}

// GetByID obtiene un documento por su ID
func (s *DocumentService) GetByID(ctx context.Context, id string) *entities.DocumentEntity {
	logger.Debug(ctx, "Inicio del metodo GetByID")
	return s.repo.GetByID(ctx, id)
}

// Create crea un nuevo documento
func (s *DocumentService) Create(ctx context.Context, document *entities.DocumentRequest) (*entities.DocumentEntity, error) {
	logger.Debug(ctx, "Inicio del metodo Create")
	return s.repo.Create(ctx, document)
}

// Update actualiza un documento existente
func (s *DocumentService) Update(ctx context.Context, document *entities.DocumentEntity) error {
	logger.Debug(ctx, "Inicio del metodo Update")
	return s.repo.Update(ctx, document)
}

// Delete elimina un documento
func (s *DocumentService) Delete(ctx context.Context, id string) error {
	logger.Debug(ctx, "Inicio del metodo Delete")
	return s.repo.Delete(ctx, id)
}
