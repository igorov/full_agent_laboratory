package main

import (
	"prometheus-agent-management-api/api/controllers"
	"prometheus-agent-management-api/pkg/repositories/impl"
	"prometheus-agent-management-api/pkg/services"

	"gorm.io/gorm"
)

// Bootstrap es el Composition Root: instancia y cablea todos los objetos concretos.
// Solo se llama una vez desde main.
func Bootstrap(db *gorm.DB) *controllers.Container {
	agentRepo := impl.NewAgentRepository(db)
	documentRepo := impl.NewDocumentRepository(db)
	agentService := services.NewAgentService(agentRepo)
	documentService := services.NewDocumentService(documentRepo)
	documentController := controllers.NewDocumentController(documentService)
	agentController := controllers.NewAgentController(agentService)
	return &controllers.Container{
		DocumentController: documentController,
		AgentController:    agentController,
	}
}
