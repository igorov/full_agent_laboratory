package main

import (
	"log"
	"prometheus-agent-management-api/api/routes"
	"prometheus-agent-management-api/cmd/server"
	"prometheus-agent-management-api/cmd/utils/database"
	"prometheus-agent-management-api/cmd/utils/environment"
	logger "prometheus-agent-management-api/cmd/utils/log"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
)

func main() {
	// Cargar configuración (composition root: se lee una sola vez aquí).
	cfg, err := environment.Load()
	if err != nil {
		log.Fatal(err)
	}
	logger.SetLevel(cfg.LogLevel)

	// Conectar a la base de datos con la configuración del dominio DB.
	db, err := database.Connect(database.Config{
		Host:     cfg.Database.Host,
		Port:     cfg.Database.Port,
		User:     cfg.Database.User,
		Password: cfg.Database.Password,
		Name:     cfg.Database.Name,
		SSLMode:  cfg.Database.SSLMode,
	})
	if err != nil {
		log.Fatal(err)
	}

	app := fiber.New()
	if cfg.AppEnv == "local" {
		app.Use(server.LocalDevMiddleware())
	}
	app.Use(server.ContextServerMiddleware())
	app.Use(cors.New(cors.Config{
		AllowOrigins:     cfg.CORS.AllowOrigins,
		AllowMethods:     "GET,POST,PUT,PATCH,DELETE,OPTIONS",
		AllowHeaders:     "Origin,Content-Type,Accept,Authorization,X-Requested-With",
		ExposeHeaders:    "Content-Length,Content-Type",
		AllowCredentials: cfg.CORS.AllowCredentials,
		MaxAge:           3600,
	}))

	// Interceptor de respuestas
	app.Use(server.ResponseInterceptorMiddleware())

	// Composition Root: instancia y cablea todas las dependencias
	container := Bootstrap(db)

	// Inicia los routes
	routes.GoFiberRoutes(app, container)

	// Iniciar servidor
	server.RunServer(app)
}
