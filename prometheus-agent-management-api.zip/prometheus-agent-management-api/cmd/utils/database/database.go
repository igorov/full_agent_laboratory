package database

import (
	"errors"
	"fmt"
	"prometheus-agent-management-api/cmd/utils/log"

	"go.uber.org/zap"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

// logger es la instancia del logger utilizada internamente por el paquete database.
var logger = log.GetLogger()

// Config contiene los parámetros necesarios para abrir una conexión a Postgres.
// Es el contrato de entrada del paquete: el caller arma este struct (desde
// variables de entorno, tests, archivos, etc.) y lo pasa a Connect.
type Config struct {
	Host     string
	Port     int
	User     string
	Password string
	Name     string
	SSLMode  string
}

// Connect abre la conexión a Postgres usando la configuración recibida.
// El paquete no lee variables de entorno — esa responsabilidad es del caller.
func Connect(cfg Config) (*gorm.DB, error) {
	logger.Info("Conectando a la base de datos...")

	if cfg.User == "" || cfg.Password == "" || cfg.Host == "" || cfg.Name == "" || cfg.Port == 0 {
		return nil, errors.New("faltan parámetros necesarios para la conexión a la base de datos")
	}

	return connectPostgres(cfg)
}

// connectPostgres abre la conexión a Postgres usando el DSN construido a partir de cfg.
func connectPostgres(cfg Config) (*gorm.DB, error) {
	logger.Info(fmt.Sprintf("Conectando a Postgres %s..", cfg.Host))

	dsn := fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%d sslmode=%s", cfg.Host, cfg.User, cfg.Password, cfg.Name, cfg.Port, cfg.SSLMode)
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		logger.Error("Error al conectar a Postgres", zap.Error(err))
		return nil, fmt.Errorf("error al conectar a postgres: %w", err)
	}

	logger.Info("Conexión exitosa a Postgres")
	return db, nil
}

// CheckConnection verifica que la conexión recibida siga activa.
func CheckConnection(conn *gorm.DB) bool {
	if conn == nil {
		return false
	}
	db, err := conn.DB()
	if err != nil {
		logger.Error("Error al verificar la conexión a la base de datos", zap.Error(err))
		return false
	}

	if err := db.Ping(); err != nil {
		logger.Error("Error al verificar la conexión a la base de datos", zap.Error(err))
		return false
	}

	return true
}
