package environment

import (
	"fmt"
	"log"
	"os"

	"github.com/ilyakaznacheev/cleanenv"
)

// DatabaseConfig agrupa la configuración de conexión a Postgres.
type DatabaseConfig struct {
	Host     string `env:"DB_HOST"`
	Port     int    `env:"DB_PORT" env-default:"5432"`
	Name     string `env:"DB_NAME"`
	User     string `env:"DB_USER"`
	Password string `env:"DB_PASSWORD"`
	SSLMode  string `env:"DB_SSL_MODE" env-default:"disable"`
}

// CORSConfig agrupa la configuración de CORS.
// AllowOrigins es una lista separada por comas; usar "*" para permitir cualquier origen.
// Nota: AllowCredentials=true es incompatible con AllowOrigins="*".
type CORSConfig struct {
	AllowOrigins     string `env:"CORS_ALLOW_ORIGINS" env-default:"*"`
	AllowCredentials bool   `env:"CORS_ALLOW_CREDENTIALS" env-default:"false"`
}

// Config representa toda la configuración de la aplicación, agrupada por dominio.
// Cada capa recibe únicamente el sub-struct que necesita.
type Config struct {
	Port     int    `env:"PORT" env-default:"8080"` // Puerto del servidor (Cloud Run usa PORT)
	LogLevel string `env:"LOG_LEVEL" env-default:"info"`
	AppEnv   string `env:"APP_ENV" env-default:"production"`
	Database DatabaseConfig
	CORS     CORSConfig
}

// Load lee la configuración desde un archivo .env (si existe) o desde las
// variables de entorno del sistema. No mantiene estado global: retorna la
// config para que el caller la inyecte donde corresponda.
func Load() (Config, error) {
	log.Println("[INFO] Cargando variables de entorno...")

	var cfg Config
	envFile := ".env"
	if _, err := os.Stat(envFile); err == nil {
		log.Println("[INFO] Archivo .env encontrado, cargando configuración local...")
		if err := cleanenv.ReadConfig(envFile, &cfg); err != nil {
			log.Printf("[ERROR] Error al cargar el archivo .env: %v\n", err)
			return Config{}, fmt.Errorf("error cargando .env: %w", err)
		}
	} else {
		log.Println("[INFO] No se encontró archivo .env, usando variables de entorno del sistema...")
		if err := cleanenv.ReadEnv(&cfg); err != nil {
			log.Printf("[ERROR] Error al cargar las variables de entorno: %v\n", err)
			return Config{}, fmt.Errorf("error cargando variables de entorno: %w", err)
		}
	}

	log.Println("[INFO] Variables de entorno cargadas exitosamente")
	return cfg, nil
}
