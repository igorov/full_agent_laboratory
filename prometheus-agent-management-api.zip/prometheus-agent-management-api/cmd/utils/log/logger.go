package log

import (
	"context"
	"os"

	"prometheus-agent-management-api/pkg/appctx"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

var log *zap.Logger
var atomicLevel zap.AtomicLevel

// init inicializa el logger global con la configuración de nivel y encoder al arrancar el paquete.
func init() {
	logLevel := getLogLevel()
	atomicLevel = zap.NewAtomicLevelAt(logLevel)

	encoderCfg := zap.NewProductionEncoderConfig()
	encoderCfg.TimeKey = "time"
	encoderCfg.EncodeTime = zapcore.TimeEncoderOfLayout("02-01-2006 15:04:05.000")
	encoderCfg.EncodeLevel = zapcore.LowercaseLevelEncoder

	config := zap.Config{
		Level:             atomicLevel,
		Development:       false,
		DisableCaller:     false,
		DisableStacktrace: false,
		Sampling:          nil,
		Encoding:          "json",
		EncoderConfig:     encoderCfg,
		OutputPaths:       []string{"stderr"},
		ErrorOutputPaths:  []string{"stderr"},
		InitialFields: map[string]interface{}{
			"pid":      os.Getpid(),
			"hostname": getHostname(),
			"system":   "prometheus-agent-management-api",
		},
	}

	var err error
	log, err = config.Build()
	if err != nil {
		panic("Falló al inicializar logger: " + err.Error())
	}

	defer log.Sync()
}

// getLogLevel lee la variable de entorno LOG_LEVEL y retorna el nivel de log correspondiente.
// Retorna InfoLevel si la variable no está definida o contiene un valor inválido.
func getLogLevel() zapcore.Level {
	logLevelStr := os.Getenv("LOG_LEVEL")
	if logLevelStr == "" {
		return zap.InfoLevel // por defecto
	}

	logLevel, err := zapcore.ParseLevel(logLevelStr)
	if err != nil {
		return zap.InfoLevel // por defecto
	}

	return logLevel
}

// SetLevel actualiza dinámicamente el nivel de log del logger global sin reiniciar la aplicación.
func SetLevel(levelStr string) {
	logLevel, err := zapcore.ParseLevel(levelStr)
	if err != nil {
		return
	}
	atomicLevel.SetLevel(logLevel)
}

// GetLogger retorna la instancia global del logger zap.
func GetLogger() *zap.Logger {
	return log
}

// getInternalLogger retorna el logger con un nivel de caller skip adicional,
// de modo que los logs muestren el archivo y línea del código que invocó el helper, no el helper mismo.
func getInternalLogger() *zap.Logger {
	return log.WithOptions(zap.AddCallerSkip(1))
}

// getHostname retorna el nombre del host donde corre la aplicación.
func getHostname() string {
	hostname, err := os.Hostname()
	if err != nil {
		panic("Falló al obtener hostname: " + err.Error())
	}
	return hostname
}

// contextFields extrae del contexto los valores de trazabilidad y los retorna como campos zap.
func contextFields(ctx context.Context) []zap.Field {
	return []zap.Field{
		zap.String("transactionId", appctx.GetTransactionID(ctx)),
		zap.String("applicationId", appctx.GetApplicationID(ctx)),
		zap.String("processId", appctx.GetProcessID(ctx)),
		zap.String("artifactChain", appctx.GetArtifactChain(ctx)),
		zap.String("userEmail", appctx.GetUserEmail(ctx)),
	}
}

// Info registra un mensaje de nivel INFO con los campos de trazabilidad del contexto.
func Info(ctx context.Context, message string) {
	getInternalLogger().Info(message, contextFields(ctx)...)
}

// Debug registra un mensaje de nivel DEBUG con los campos de trazabilidad del contexto.
func Debug(ctx context.Context, message string) {
	getInternalLogger().Debug(message, contextFields(ctx)...)
}

// Warn registra un mensaje de nivel WARN con los campos de trazabilidad del contexto.
func Warn(ctx context.Context, message string) {
	getInternalLogger().Warn(message, contextFields(ctx)...)
}

// Error registra un mensaje de nivel ERROR con el error y los campos de trazabilidad del contexto.
func Error(ctx context.Context, message string, err error) {
	getInternalLogger().Error(message, append(contextFields(ctx), zap.Error(err))...)
}

// Panic registra un mensaje de nivel PANIC con el error y los campos de trazabilidad del contexto,
// luego produce un panic.
func Panic(ctx context.Context, message string, err error) {
	getInternalLogger().Panic(message, append(contextFields(ctx), zap.Error(err))...)
}

// Fatal registra un mensaje de nivel FATAL con el error y los campos de trazabilidad del contexto,
// luego termina el proceso con os.Exit(1).
func Fatal(ctx context.Context, message string, err error) {
	getInternalLogger().Fatal(message, append(contextFields(ctx), zap.Error(err))...)
}
