package server

import (
	"context"
	_ "embed"
	"encoding/base64"
	"encoding/json"

	"prometheus-agent-management-api/pkg/appctx"

	"github.com/gofiber/fiber/v2"
	"github.com/google/uuid"
)

//go:embed dev/mock-userinfo.json
var mockUserInfoFile []byte

var (
	// transactionIDHeader es el nombre del header HTTP para el ID de transacción.
	transactionIDHeader = "Transaction-ID"
	// applicationIDHeader es el nombre del header HTTP para el ID de aplicación.
	applicationIDHeader = "Application-ID"
	// processIDHeader es el nombre del header HTTP para el ID de proceso.
	processIDHeader = "Process-ID"
	// artifactChainHeader es el nombre del header HTTP para la cadena de artefactos.
	artifactChainHeader = "Artifact-Chain"
	// gcpUserInfoHeader es el nombre del header inyectado por GCP API Gateway con la info del usuario autenticado.
	gcpUserInfoHeader = "x-apigateway-api-userinfo"
)

// gcpUserInfo representa la carga útil del JWT decodificado que inyecta GCP API Gateway
// en el header x-apigateway-api-userinfo como JSON codificado en Base64.
type gcpUserInfo struct {
	Name          string `json:"name"`
	Picture       string `json:"picture"`
	Iss           string `json:"iss"`
	Aud           string `json:"aud"`
	AuthTime      int64  `json:"auth_time"`
	UserID        string `json:"user_id"`
	Sub           string `json:"sub"`
	Iat           int64  `json:"iat"`
	Exp           int64  `json:"exp"`
	Email         string `json:"email"`
	EmailVerified bool   `json:"email_verified"`
	CompanyID     string `json:"id_empresa"`
	Firebase      struct {
		Identities struct {
			Google []string `json:"google.com"`
			Email  []string `json:"email"`
		} `json:"identities"`
		SignInProvider string `json:"sign_in_provider"`
	} `json:"firebase"`
}

// LocalDevMiddleware inyecta el header del API Gateway con datos del archivo dev/mock-userinfo.json.
// Solo debe registrarse cuando APP_ENV=local. En producción nunca se llama.
func LocalDevMiddleware() fiber.Handler {
	mockHeader := base64.RawURLEncoding.EncodeToString(mockUserInfoFile)
	return func(c *fiber.Ctx) error {
		if c.Get(gcpUserInfoHeader) == "" {
			c.Request().Header.Set(gcpUserInfoHeader, mockHeader)
		}
		return c.Next()
	}
}

// ContextServerMiddleware extrae los headers de trazabilidad y la información del usuario
// del header GCP API Gateway, y los almacena en el contexto de cada petición.
func ContextServerMiddleware() fiber.Handler {
	return func(c *fiber.Ctx) error {
		transactionID := c.Get(transactionIDHeader)
		if transactionID == "" {
			transactionID = uuid.New().String()
		}

		applicationID := c.Get(applicationIDHeader)

		processID := c.Get(processIDHeader)
		if processID == "" {
			processID = uuid.New().String()
		}

		// Concatenar artifactChain con el system actual
		currentSystem := "prometheus-agent-management-api"
		artifactChain := c.Get(artifactChainHeader)
		if artifactChain != "" {
			artifactChain = artifactChain + " | " + currentSystem
		} else {
			artifactChain = currentSystem
		}

		email := ""
		companyID := ""
		gcpHeader := c.Get(gcpUserInfoHeader)
		if gcpHeader != "" {
			decoded, err := base64.RawURLEncoding.DecodeString(gcpHeader)
			if err != nil {
				decoded, err = base64.StdEncoding.DecodeString(gcpHeader)
			}
			if err == nil {
				var userInfo gcpUserInfo
				if json.Unmarshal(decoded, &userInfo) == nil {
					email = userInfo.Email
					companyID = userInfo.CompanyID
				}
			}
		}

		ctx := c.UserContext()
		ctx = context.WithValue(ctx, appctx.KeyTransactionID, transactionID)
		ctx = context.WithValue(ctx, appctx.KeyApplicationID, applicationID)
		ctx = context.WithValue(ctx, appctx.KeyProcessID, processID)
		ctx = context.WithValue(ctx, appctx.KeyArtifactChain, artifactChain)
		ctx = context.WithValue(ctx, appctx.KeyUserEmail, email)
		ctx = context.WithValue(ctx, appctx.KeyCompanyID, companyID)
		c.SetUserContext(ctx)

		return c.Next()
	}
}

// ResponseInterceptorMiddleware propaga los headers de trazabilidad (transactionID, applicationID,
// processID y artifactChain) en la respuesta HTTP de cada petición.
func ResponseInterceptorMiddleware() fiber.Handler {
	return func(c *fiber.Ctx) error {
		err := c.Next()

		// Agrega los headers al encabezado de la respuesta
		ctx := c.UserContext()
		c.Set(transactionIDHeader, appctx.GetTransactionID(ctx))
		c.Set(applicationIDHeader, appctx.GetApplicationID(ctx))
		c.Set(processIDHeader, appctx.GetProcessID(ctx))
		c.Set(artifactChainHeader, appctx.GetArtifactChain(ctx))

		// Devuelve el error, si lo hay
		return err
	}
}
