package controllers

// Container agrupa todos los controllers de la aplicación y actuar como punto de inyección de dependencias HTTP.
type Container struct {
	// AgentController gestiona los endpoints de agentes.
	AgentController *AgentController
	// DocumentController gestiona los endpoints de documentos.
	DocumentController *DocumentController
}
