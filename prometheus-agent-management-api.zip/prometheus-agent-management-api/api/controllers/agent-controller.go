package controllers

import (
	"fmt"
	logger "prometheus-agent-management-api/cmd/utils/log"
	"prometheus-agent-management-api/pkg/appctx"
	"prometheus-agent-management-api/pkg/entities"
	"prometheus-agent-management-api/pkg/services"

	"github.com/gofiber/fiber/v2"
)

// AgentController maneja las peticiones HTTP relacionadas con la gestión de agentes.
type AgentController struct {
	service *services.AgentService
}

// NewAgentController crea y retorna una nueva instancia de AgentController con el servicio indicado.
func NewAgentController(service *services.AgentService) *AgentController {
	return &AgentController{service: service}
}

// GetByCompany maneja la petición GET para obtener agentes por company ID
func (ctrl *AgentController) GetByCompany(c *fiber.Ctx) error {
	ctx := c.UserContext()
	logger.Debug(ctx, "Inicio de método GetByCompany en controller")
	companyID := appctx.GetCompanyID(ctx)
	agents := ctrl.service.GetByCompany(ctx, companyID)
	response := entities.AgentListResponse{
		Status: "success",
		Data:   agents,
	}
	return c.Status(fiber.StatusOK).JSON(response)
}

// GetById maneja la petición GET para obtener un agente por su ID
func (ctrl *AgentController) GetById(c *fiber.Ctx) error {
	ctx := c.UserContext()
	logger.Debug(ctx, "Inicio de método GetById en controller")
	agentID := c.Params("agentID")
	agent := ctrl.service.GetByID(ctx, agentID)
	response := entities.AgentResponse{
		Status: "success",
		Data:   *agent,
	}
	return c.Status(fiber.StatusOK).JSON(response)
}

// DisableById maneja la petición DELETE para deshabilitar un agente por su ID
func (ctrl *AgentController) DisableById(c *fiber.Ctx) error {
	ctx := c.UserContext()
	logger.Debug(ctx, "Inicio de método DisableById en controller")
	agentID := c.Params("agentID")
	err := ctrl.service.Disable(ctx, agentID)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"status": "error",
			"error":  err.Error(),
		})
	}
	return c.Status(fiber.StatusOK).JSON(fiber.Map{
		"status": "success",
	})
}

// Create maneja la petición POST para crear un nuevo agente.
func (ctrl *AgentController) Create(c *fiber.Ctx) error {
	ctx := c.UserContext()
	logger.Debug(ctx, "Inicio de método Create en controller")
	agent := &entities.AgentCreateRequest{}
	if err := c.BodyParser(agent); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"status": "error",
			"error":  err.Error(),
		})
	}

	logger.Debug(ctx, fmt.Sprintf("GetCompanyID: %s", appctx.GetCompanyID(ctx)))

	agent.IDEmpresa = appctx.GetCompanyID(ctx)
	createdAgent, err := ctrl.service.Create(ctx, agent)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"status": "error",
			"error":  err.Error(),
		})
	}

	response := entities.AgentResponse{
		Status: "success",
		Data:   *createdAgent,
	}
	return c.Status(fiber.StatusOK).JSON(response)
}

// Update maneja la petición PUT para actualizar un agente existente por su ID.
func (ctrl *AgentController) Update(c *fiber.Ctx) error {
	ctx := c.UserContext()
	logger.Debug(ctx, "Inicio de método Update en controller")
	agentID := c.Params("agentID")
	agent := &entities.AgentCreateRequest{}
	if err := c.BodyParser(agent); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"status": "error",
			"error":  err.Error(),
		})
	}
	agent.IDEmpresa = appctx.GetCompanyID(ctx)
	updatedAgent, err := ctrl.service.Update(ctx, agentID, agent)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"status": "error",
			"error":  err.Error(),
		})
	}
	response := entities.AgentResponse{
		Status: "success",
		Data:   *updatedAgent,
	}
	return c.Status(fiber.StatusOK).JSON(response)
}
