package controllers

import (
	logger "prometheus-agent-management-api/cmd/utils/log"
	"prometheus-agent-management-api/pkg/appctx"
	"prometheus-agent-management-api/pkg/services"

	"github.com/gofiber/fiber/v2"
)

// DocumentController maneja las peticiones HTTP relacionadas con la gestión de documentos.
type DocumentController struct {
	service *services.DocumentService
}

// NewDocumentController crea y retorna una nueva instancia de DocumentController con el servicio indicado.
func NewDocumentController(service *services.DocumentService) *DocumentController {
	return &DocumentController{service: service}
}

// GetByAgent maneja la petición GET para obtener los documentos asociados a un agente.
// Acepta el parámetro de ruta agentID y el query param opcional name para filtrar por nombre.
func (ctrl *DocumentController) GetByAgent(c *fiber.Ctx) error {
	ctx := c.UserContext()
	logger.Debug(ctx, "Inicio de método GetByAgent en controller")
	companyId := appctx.GetCompanyID(ctx)
	agentID := c.Params("agentID")
	name := c.Query("name")
	documents := ctrl.service.GetByAgent(ctx, agentID, name, companyId)
	return c.Status(fiber.StatusOK).JSON(documents)
}
