package routes

import (
	"prometheus-agent-management-api/api/controllers"

	"github.com/gofiber/fiber/v2"
)

// GoFiberRoutes registra todas las rutas de la aplicación bajo el prefijo /v1
// e inyecta los controllers del container en cada grupo.
func GoFiberRoutes(app *fiber.App, c *controllers.Container) {
	api := app.Group("/v1")

	registerAgentApiRoutes(api, c.AgentController, c.DocumentController)
}

// registerAgentApiRoutes registra bajo /agents las rutas CRUD de agentes
// y bajo /:agentID/documents las rutas de documentos asociados.
func registerAgentApiRoutes(r fiber.Router, agentCtrl *controllers.AgentController, docCtrl *controllers.DocumentController) {
	agentApi := r.Group("/agents")

	agentApi.Get("/", agentCtrl.GetByCompany)
	agentApi.Post("/", agentCtrl.Create)
	agentApi.Put("/:agentID", agentCtrl.Update)
	agentApi.Delete("/:agentID", agentCtrl.DisableById)
	agentApi.Get("/:agentID", agentCtrl.GetById)

	documentApi := agentApi.Group("/:agentID/documents")
	documentApi.Get("/", docCtrl.GetByAgent)
	// documentApi.Post("/", docCtrl.Create)
	// documentApi.Get("/:docID", docCtrl.GetById)
	// documentApi.Put("/:docID", docCtrl.Update)
	// documentApi.Delete("/:docID", docCtrl.Delete)
}
