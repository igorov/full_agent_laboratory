package services_test

import (
	"context"
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"prometheus-agent-management-api/pkg/entities"
	"prometheus-agent-management-api/pkg/services"
	"prometheus-agent-management-api/tests/mocks"
)

func TestGetByCompany_CompanyExists_ReturnsAgents(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	expectedAgents := []entities.AgentEntity{
		{ID: "agent-001", AgentName: "Agent One", IDEmpresa: "company-123"},
		{ID: "agent-002", AgentName: "Agent Two", IDEmpresa: "company-123"},
	}
	mockRepo.On("GetByCompany", mock.Anything, "company-123").Return(expectedAgents)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result := svc.GetByCompany(ctx, "company-123")

	// Assert
	assert.Len(t, result, 2)
	assert.Equal(t, expectedAgents, result)
}

func TestGetByCompany_EmptyResult_ReturnsEmptySlice(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	mockRepo.On("GetByCompany", mock.Anything, "company-999").Return([]entities.AgentEntity{})
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result := svc.GetByCompany(ctx, "company-999")

	// Assert
	assert.Empty(t, result)
}

func TestGetByID_AgentExists_ReturnsAgent(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	expectedAgent := &entities.AgentEntity{ID: "agent-001", AgentName: "Agent One", IDEmpresa: "company-123"}
	mockRepo.On("GetByID", mock.Anything, "agent-001").Return(expectedAgent)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result := svc.GetByID(ctx, "agent-001")

	// Assert
	assert.NotNil(t, result)
	assert.Equal(t, "agent-001", result.ID)
	assert.Equal(t, "Agent One", result.AgentName)
}

func TestGetByID_AgentNotFound_ReturnsNil(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	mockRepo.On("GetByID", mock.Anything, "agent-999").Return((*entities.AgentEntity)(nil))
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result := svc.GetByID(ctx, "agent-999")

	// Assert
	assert.Nil(t, result)
}

func TestCreate_ValidInput_AgentCreated(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	request := &entities.AgentCreateRequest{
		AgentName:   "New Agent",
		AgentPrompt: "Prompt text",
		IDEmpresa:   "company-123",
	}
	createdAgent := &entities.AgentEntity{
		ID:          "agent-new",
		AgentName:   "New Agent",
		AgentPrompt: "Prompt text",
		IDEmpresa:   "company-123",
	}
	mockRepo.On("Create", mock.Anything, request).Return(createdAgent, nil)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result, err := svc.Create(ctx, request)

	// Assert
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.Equal(t, "agent-new", result.ID)
	assert.Equal(t, "New Agent", result.AgentName)
}

func TestCreate_RepositoryError_ReturnsError(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	request := &entities.AgentCreateRequest{AgentName: "Agent", IDEmpresa: "company-123"}
	repoErr := errors.New("database error")
	mockRepo.On("Create", mock.Anything, request).Return((*entities.AgentEntity)(nil), repoErr)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result, err := svc.Create(ctx, request)

	// Assert
	assert.Error(t, err)
	assert.Nil(t, result)
	assert.Contains(t, err.Error(), "database error")
}

func TestUpdate_ValidInput_AgentUpdated(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	request := &entities.AgentCreateRequest{AgentName: "Updated Agent", IDEmpresa: "company-123"}
	updatedAgent := &entities.AgentEntity{ID: "agent-001", AgentName: "Updated Agent", IDEmpresa: "company-123"}
	mockRepo.On("Update", mock.Anything, "agent-001", request).Return(updatedAgent, nil)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result, err := svc.Update(ctx, "agent-001", request)

	// Assert
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.Equal(t, "Updated Agent", result.AgentName)
}

func TestUpdate_RepositoryError_ReturnsError(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	request := &entities.AgentCreateRequest{AgentName: "Agent", IDEmpresa: "company-123"}
	repoErr := errors.New("update failed")
	mockRepo.On("Update", mock.Anything, "agent-001", request).Return((*entities.AgentEntity)(nil), repoErr)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result, err := svc.Update(ctx, "agent-001", request)

	// Assert
	assert.Error(t, err)
	assert.Nil(t, result)
	assert.Contains(t, err.Error(), "update failed")
}

func TestDelete_AgentExists_ReturnsNil(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	mockRepo.On("Delete", mock.Anything, "agent-001").Return(nil)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	err := svc.Delete(ctx, "agent-001")

	// Assert
	assert.NoError(t, err)
}

func TestDelete_RepositoryError_ReturnsError(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	repoErr := errors.New("delete failed")
	mockRepo.On("Delete", mock.Anything, "agent-001").Return(repoErr)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	err := svc.Delete(ctx, "agent-001")

	// Assert
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "delete failed")
}

func TestDisable_AgentExists_ReturnsNil(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	mockRepo.On("Disable", mock.Anything, "agent-001").Return(nil)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	err := svc.Disable(ctx, "agent-001")

	// Assert
	assert.NoError(t, err)
}

func TestDisable_RepositoryError_ReturnsError(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	repoErr := errors.New("disable failed")
	mockRepo.On("Disable", mock.Anything, "agent-001").Return(repoErr)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	err := svc.Disable(ctx, "agent-001")

	// Assert
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "disable failed")
}

func TestGetUserInfo_Called_ReturnsFixedInfo(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockAgentRepository)
	svc := services.NewAgentService(mockRepo)
	ctx := context.Background()

	// Act
	result := svc.GetUserInfo(ctx)

	// Assert
	assert.Equal(t, "123", result.IDUsuario)
	assert.Equal(t, "user", result.Username)
	assert.Equal(t, "user@example.com", result.Email)
	assert.Equal(t, "456", result.IDEmpresa)
	assert.Contains(t, result.Perfiles, "PO")
}
