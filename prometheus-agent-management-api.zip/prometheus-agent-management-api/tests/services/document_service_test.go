package services_test

import (
	"context"
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"prometheus-agent-management-api/pkg/entities"
	"prometheus-agent-management-api/pkg/services"
	"prometheus-agent-management-api/tests/mocks"
)

func TestGetByAgent_AgentExists_ReturnsDocuments(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	expectedDocs := []entities.DocumentEntity{
		{ID: "doc-001", Name: "Document One"},
		{ID: "doc-002", Name: "Document Two"},
	}
	mockRepo.On("GetByAgent", mock.Anything, "agent-001", "", "company-123").Return(expectedDocs)
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result := svc.GetByAgent(ctx, "agent-001", "", "company-123")

	// Assert
	assert.Len(t, result, 2)
	assert.Equal(t, expectedDocs, result)
}

func TestGetByAgent_NoDocuments_ReturnsEmptySlice(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	mockRepo.On("GetByAgent", mock.Anything, "agent-999", "", "company-123").Return([]entities.DocumentEntity{})
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result := svc.GetByAgent(ctx, "agent-999", "", "company-123")

	// Assert
	assert.Empty(t, result)
}

func TestGetByAgent_WithNameFilter_ReturnsFilteredDocuments(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	expectedDocs := []entities.DocumentEntity{
		{ID: "doc-001", Name: "manual"},
	}
	mockRepo.On("GetByAgent", mock.Anything, "agent-001", "manual", "company-123").Return(expectedDocs)
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result := svc.GetByAgent(ctx, "agent-001", "manual", "company-123")

	// Assert
	assert.Len(t, result, 1)
	assert.Equal(t, "manual", result[0].Name)
}

func TestGetDocumentByID_DocumentExists_ReturnsDocument(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	expectedDoc := &entities.DocumentEntity{ID: "doc-001", Name: "Document One", URL: "https://storage.example.com/doc.pdf"}
	mockRepo.On("GetByID", mock.Anything, "doc-001").Return(expectedDoc)
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result := svc.GetByID(ctx, "doc-001")

	// Assert
	assert.NotNil(t, result)
	assert.Equal(t, "doc-001", result.ID)
	assert.Equal(t, "Document One", result.Name)
}

func TestGetDocumentByID_DocumentNotFound_ReturnsNil(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	mockRepo.On("GetByID", mock.Anything, "doc-999").Return((*entities.DocumentEntity)(nil))
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result := svc.GetByID(ctx, "doc-999")

	// Assert
	assert.Nil(t, result)
}

func TestCreateDocument_ValidInput_DocumentCreated(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	resourceURL := "https://storage.example.com/doc.pdf"
	request := &entities.DocumentRequest{
		Name:           "Document One",
		DocumentTypeID: 1,
		Resource:       &resourceURL,
	}
	createdDoc := &entities.DocumentEntity{
		ID:   "doc-new",
		Name: "Document One",
		URL:  resourceURL,
	}
	mockRepo.On("Create", mock.Anything, request).Return(createdDoc, nil)
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result, err := svc.Create(ctx, request)

	// Assert
	assert.NoError(t, err)
	assert.NotNil(t, result)
	assert.Equal(t, "doc-new", result.ID)
	assert.Equal(t, "Document One", result.Name)
}

func TestCreateDocument_RepositoryError_ReturnsError(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	request := &entities.DocumentRequest{Name: "Document One", DocumentTypeID: 1}
	repoErr := errors.New("database error")
	mockRepo.On("Create", mock.Anything, request).Return((*entities.DocumentEntity)(nil), repoErr)
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	result, err := svc.Create(ctx, request)

	// Assert
	assert.Error(t, err)
	assert.Nil(t, result)
	assert.Contains(t, err.Error(), "database error")
}

func TestUpdateDocument_ValidInput_ReturnsNil(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	document := &entities.DocumentEntity{ID: "doc-001", Name: "Updated Document"}
	mockRepo.On("Update", mock.Anything, document).Return(nil)
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	err := svc.Update(ctx, document)

	// Assert
	assert.NoError(t, err)
}

func TestUpdateDocument_RepositoryError_ReturnsError(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	document := &entities.DocumentEntity{ID: "doc-001", Name: "Document"}
	repoErr := errors.New("update failed")
	mockRepo.On("Update", mock.Anything, document).Return(repoErr)
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	err := svc.Update(ctx, document)

	// Assert
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "update failed")
}

func TestDeleteDocument_DocumentExists_ReturnsNil(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	mockRepo.On("Delete", mock.Anything, "doc-001").Return(nil)
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	err := svc.Delete(ctx, "doc-001")

	// Assert
	assert.NoError(t, err)
}

func TestDeleteDocument_RepositoryError_ReturnsError(t *testing.T) {
	// Arrange
	mockRepo := new(mocks.MockDocumentRepository)
	repoErr := errors.New("delete failed")
	mockRepo.On("Delete", mock.Anything, "doc-001").Return(repoErr)
	svc := services.NewDocumentService(mockRepo)
	ctx := context.Background()
	t.Cleanup(func() { mockRepo.AssertExpectations(t) })

	// Act
	err := svc.Delete(ctx, "doc-001")

	// Assert
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "delete failed")
}
