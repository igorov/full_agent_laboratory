package mocks

import (
	"context"

	"github.com/stretchr/testify/mock"
	"prometheus-agent-management-api/pkg/entities"
)

// MockAgentRepository implementa repositories.AgentRepository para pruebas unitarias.
type MockAgentRepository struct {
	mock.Mock
}

func (m *MockAgentRepository) GetByCompany(ctx context.Context, companyID string) []entities.AgentEntity {
	args := m.Called(ctx, companyID)
	return args.Get(0).([]entities.AgentEntity)
}

func (m *MockAgentRepository) GetByID(ctx context.Context, id string) *entities.AgentEntity {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil
	}
	return args.Get(0).(*entities.AgentEntity)
}

func (m *MockAgentRepository) Create(ctx context.Context, agent *entities.AgentCreateRequest) (*entities.AgentEntity, error) {
	args := m.Called(ctx, agent)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*entities.AgentEntity), args.Error(1)
}

func (m *MockAgentRepository) Update(ctx context.Context, id string, agent *entities.AgentCreateRequest) (*entities.AgentEntity, error) {
	args := m.Called(ctx, id, agent)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*entities.AgentEntity), args.Error(1)
}

func (m *MockAgentRepository) Delete(ctx context.Context, id string) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}

func (m *MockAgentRepository) Disable(ctx context.Context, id string) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}
