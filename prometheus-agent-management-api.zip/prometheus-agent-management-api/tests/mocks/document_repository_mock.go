package mocks

import (
	"context"

	"github.com/stretchr/testify/mock"
	"prometheus-agent-management-api/pkg/entities"
)

// MockDocumentRepository implementa repositories.DocumentRepository para pruebas unitarias.
type MockDocumentRepository struct {
	mock.Mock
}

func (m *MockDocumentRepository) GetByAgent(ctx context.Context, agentID string, name string, companyId string) []entities.DocumentEntity {
	args := m.Called(ctx, agentID, name, companyId)
	return args.Get(0).([]entities.DocumentEntity)
}

func (m *MockDocumentRepository) GetByID(ctx context.Context, id string) *entities.DocumentEntity {
	args := m.Called(ctx, id)
	if args.Get(0) == nil {
		return nil
	}
	return args.Get(0).(*entities.DocumentEntity)
}

func (m *MockDocumentRepository) Create(ctx context.Context, document *entities.DocumentRequest) (*entities.DocumentEntity, error) {
	args := m.Called(ctx, document)
	if args.Get(0) == nil {
		return nil, args.Error(1)
	}
	return args.Get(0).(*entities.DocumentEntity), args.Error(1)
}

func (m *MockDocumentRepository) Update(ctx context.Context, document *entities.DocumentEntity) error {
	args := m.Called(ctx, document)
	return args.Error(0)
}

func (m *MockDocumentRepository) Delete(ctx context.Context, id string) error {
	args := m.Called(ctx, id)
	return args.Error(0)
}
