package middleware_test

import (
	"encoding/base64"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gofiber/fiber/v2"
	"github.com/stretchr/testify/assert"
	server "prometheus-agent-management-api/cmd/server"
	"prometheus-agent-management-api/pkg/appctx"
)

// contextSnapshot captura los valores del contexto inyectados por el middleware.
type contextSnapshot struct {
	TransactionID string `json:"transactionID"`
	ApplicationID string `json:"applicationID"`
	ProcessID     string `json:"processID"`
	ArtifactChain string `json:"artifactChain"`
	UserEmail     string `json:"userEmail"`
	CompanyID     string `json:"companyID"`
}

func newTestApp() *fiber.App {
	app := fiber.New()
	app.Use(server.ContextServerMiddleware())
	app.Get("/test", func(c *fiber.Ctx) error {
		ctx := c.UserContext()
		return c.JSON(contextSnapshot{
			TransactionID: appctx.GetTransactionID(ctx),
			ApplicationID: appctx.GetApplicationID(ctx),
			ProcessID:     appctx.GetProcessID(ctx),
			ArtifactChain: appctx.GetArtifactChain(ctx),
			UserEmail:     appctx.GetUserEmail(ctx),
			CompanyID:     appctx.GetCompanyID(ctx),
		})
	})
	return app
}

func parseSnapshot(t *testing.T, resp *http.Response) contextSnapshot {
	t.Helper()
	body, err := io.ReadAll(resp.Body)
	assert.NoError(t, err)
	var snap contextSnapshot
	assert.NoError(t, json.Unmarshal(body, &snap))
	return snap
}

func TestContextServerMiddleware_NoHeaders_GeneratesTransactionAndProcessIDs(t *testing.T) {
	// Arrange
	app := newTestApp()
	req := httptest.NewRequest(http.MethodGet, "/test", nil)

	// Act
	resp, err := app.Test(req)

	// Assert
	assert.NoError(t, err)
	assert.Equal(t, http.StatusOK, resp.StatusCode)
	snap := parseSnapshot(t, resp)
	assert.NotEmpty(t, snap.TransactionID)
	assert.NotEmpty(t, snap.ProcessID)
}

func TestContextServerMiddleware_WithTransactionIDHeader_UsesProvidedValue(t *testing.T) {
	// Arrange
	fixedTransactionID := "txn-fixed-001"
	app := newTestApp()
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	req.Header.Set("Transaction-ID", fixedTransactionID)

	// Act
	resp, err := app.Test(req)

	// Assert
	assert.NoError(t, err)
	snap := parseSnapshot(t, resp)
	assert.Equal(t, fixedTransactionID, snap.TransactionID)
}

func TestContextServerMiddleware_WithApplicationIDHeader_UsesProvidedValue(t *testing.T) {
	// Arrange
	fixedAppID := "app-prometheus-001"
	app := newTestApp()
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	req.Header.Set("Application-ID", fixedAppID)

	// Act
	resp, err := app.Test(req)

	// Assert
	assert.NoError(t, err)
	snap := parseSnapshot(t, resp)
	assert.Equal(t, fixedAppID, snap.ApplicationID)
}

func TestContextServerMiddleware_NoArtifactChain_SetsSystemName(t *testing.T) {
	// Arrange
	app := newTestApp()
	req := httptest.NewRequest(http.MethodGet, "/test", nil)

	// Act
	resp, err := app.Test(req)

	// Assert
	assert.NoError(t, err)
	snap := parseSnapshot(t, resp)
	assert.Equal(t, "prometheus-agent-management-api", snap.ArtifactChain)
}

func TestContextServerMiddleware_WithExistingArtifactChain_AppendsSystemName(t *testing.T) {
	// Arrange
	upstreamChain := "upstream-service"
	app := newTestApp()
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	req.Header.Set("Artifact-Chain", upstreamChain)

	// Act
	resp, err := app.Test(req)

	// Assert
	assert.NoError(t, err)
	snap := parseSnapshot(t, resp)
	assert.Equal(t, "upstream-service | prometheus-agent-management-api", snap.ArtifactChain)
}

func TestContextServerMiddleware_WithValidGCPUserInfo_ExtractsEmailAndCompanyID(t *testing.T) {
	// Arrange
	userInfo := map[string]interface{}{
		"email":      "jane.doe@example.com",
		"id_empresa": "company-456",
	}
	payload, _ := json.Marshal(userInfo)
	encodedHeader := base64.RawURLEncoding.EncodeToString(payload)

	app := newTestApp()
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	req.Header.Set("x-apigateway-api-userinfo", encodedHeader)

	// Act
	resp, err := app.Test(req)

	// Assert
	assert.NoError(t, err)
	snap := parseSnapshot(t, resp)
	assert.Equal(t, "jane.doe@example.com", snap.UserEmail)
	assert.Equal(t, "company-456", snap.CompanyID)
}

func TestContextServerMiddleware_WithInvalidGCPHeader_EmptyEmailAndCompanyID(t *testing.T) {
	// Arrange
	app := newTestApp()
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	req.Header.Set("x-apigateway-api-userinfo", "!!!invalid-base64!!!")

	// Act
	resp, err := app.Test(req)

	// Assert
	assert.NoError(t, err)
	snap := parseSnapshot(t, resp)
	assert.Empty(t, snap.UserEmail)
	assert.Empty(t, snap.CompanyID)
}

func TestResponseInterceptorMiddleware_SetsResponseHeaders(t *testing.T) {
	// Arrange
	fixedTransactionID := "txn-resp-001"
	fixedAppID := "app-resp-001"

	app := fiber.New()
	app.Use(server.ContextServerMiddleware())
	app.Use(server.ResponseInterceptorMiddleware())
	app.Get("/test", func(c *fiber.Ctx) error {
		return c.SendStatus(http.StatusOK)
	})

	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	req.Header.Set("Transaction-ID", fixedTransactionID)
	req.Header.Set("Application-ID", fixedAppID)

	// Act
	resp, err := app.Test(req)

	// Assert
	assert.NoError(t, err)
	assert.Equal(t, fixedTransactionID, resp.Header.Get("Transaction-ID"))
	assert.Equal(t, fixedAppID, resp.Header.Get("Application-ID"))
	assert.NotEmpty(t, resp.Header.Get("Process-ID"))
	assert.NotEmpty(t, resp.Header.Get("Artifact-Chain"))
}
